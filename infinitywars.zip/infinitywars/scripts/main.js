const button = document.querySelector('.burgerButton')
const burgerMenu = document.querySelector('.listBurger')

button.addEventListener('click', function () {
  burgerMenu.classList.toggle('displayBurger')
});

const accueil = document.querySelector('.txt')